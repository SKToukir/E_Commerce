-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 29, 2015 at 11:01 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecommerce_batch17`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(2) NOT NULL AUTO_INCREMENT,
  `admin_full_name` varchar(50) NOT NULL,
  `admin_email_address` varchar(100) NOT NULL,
  `admin_password` varchar(32) NOT NULL,
  `access_lavel` tinyint(1) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_full_name`, `admin_email_address`, `admin_password`, `access_lavel`) VALUES
(1, 'Md.Nafiul Islam', 'nafiulislamcse@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1),
(2, 'Md.Rafiul Islam', 'rafiulislamcse@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `category_id` int(2) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `category_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`, `publication_status`) VALUES
(6, 'স্কুল ও কলেজ বই', '<span >স্কুল ও কলেজ বই-এর বইগুলোর ভিতর অনুসন্ধান করুন</span>', 1),
(7, 'মুক্তিযুদ্ধ', '<span >মুক্তিযুদ্ধ-এর বইগুলোর ভিতর অনুসন্ধান করুন</span>', 1),
(8, 'গণিত, বিজ্ঞান ও প্রযুক্তি', '<span >গণিত, বিজ্ঞান ও প্রযুক্তি-এর বইগুলোর ভিতর অনুসন্ধান করুন</span>', 1),
(9, 'রান্নাবান্না, খাদ্য ও পুষ্টি', '<span >রান্নাবান্না, খাদ্য ও পুষ্টি-এর বইগুলোর ভিতর অনুসন্ধান করুন <br></span>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `customer_id` int(7) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `contact_number` varchar(14) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(25) NOT NULL,
  `zip_code` varchar(5) NOT NULL,
  `activation_status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `first_name`, `last_name`, `email_address`, `password`, `contact_number`, `address`, `city`, `country`, `zip_code`, `activation_status`) VALUES
(16, 'Md. Shafiul', 'Alam', 'topu1826@gmail.com', '111111', '01914872766', '8/A, Mirza Golam Hossain Road, Dhanmondi, Dhaka', 'Dhaka', 'BD', '6622', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manufacturer`
--

CREATE TABLE IF NOT EXISTS `tbl_manufacturer` (
  `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer_name` varchar(50) NOT NULL,
  `manufacturer_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_manufacturer`
--

INSERT INTO `tbl_manufacturer` (`manufacturer_id`, `manufacturer_name`, `manufacturer_description`, `publication_status`) VALUES
(5, 'অনুপম প্রকাশনী', '<ul class="ul-c-al" ><li ><a href="http://www.rokomari.com/publisher/11" class="lnk-1" >অনুপম প্রকাশনী</a></li></ul>', 1),
(6, 'অংকুশ', '<ul class="ul-c-al" ><li ><a href="http://www.rokomari.com/publisher/630" class="lnk-1" >অংকুশ</a></li></ul>', 1),
(7, 'অক্সফোর্ড ইউনিভার্সিটি প্রেস', '<ul class="ul-c-al" ><li ><a href="http://www.rokomari.com/publisher/1188" class="lnk-1" >অক্সফোর্ড ইউনিভার্সিটি প্রেস</a></li></ul>', 1),
(8, 'অনার্স পাবলিকেশন্স', '<ul class="ul-c-al" ><li ><a href="http://www.rokomari.com/publisher/803" class="lnk-1" >অনার্স পাবলিকেশন্স</a></li></ul>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_id` int(7) NOT NULL AUTO_INCREMENT,
  `customer_id` int(7) NOT NULL,
  `shipping_id` int(7) NOT NULL,
  `payment_id` int(7) NOT NULL,
  `order_total` float(10,2) NOT NULL,
  `order_status` varchar(10) NOT NULL DEFAULT 'Pending',
  `order_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `payment_id`, `order_total`, `order_status`, `order_date_time`) VALUES
(3, 11, 3, 3, 690.00, 'Pending', '0000-00-00 00:00:00'),
(4, 11, 3, 4, 575.00, 'Pending', '0000-00-00 00:00:00'),
(5, 12, 4, 5, 632.50, 'Pending', '2015-03-25 05:51:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE IF NOT EXISTS `tbl_order_details` (
  `order_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(7) NOT NULL,
  `product_id` int(5) NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_sales_quantity` int(3) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  PRIMARY KEY (`order_details_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_details_id`, `order_id`, `product_id`, `product_price`, `product_name`, `product_sales_quantity`, `product_image`) VALUES
(4, 3, 11, 100.00, 'Secendary Physics', 3, './image/product_image/bookcovers_68905.GIF'),
(3, 3, 12, 150.00, 'Secendary Accounting', 2, './image/product_image/bookcovers_68919.GIF'),
(5, 4, 11, 100.00, 'Secendary Physics', 3, './image/product_image/bookcovers_68905.GIF'),
(6, 4, 13, 200.00, 'Secendary Science', 1, './image/product_image/bookcovers_68921.gif'),
(7, 5, 13, 200.00, 'Secendary Science', 2, './image/product_image/bookcovers_68921.gif'),
(8, 5, 12, 150.00, 'Secendary Accounting', 1, './image/product_image/bookcovers_68919.GIF');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `payment_id` int(5) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(30) NOT NULL,
  `payment_status` varchar(10) NOT NULL DEFAULT 'Pending',
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `payment_type`, `payment_status`, `payment_date`) VALUES
(3, 'cash_on_delivery', 'Pending', '2015-03-24 05:49:55'),
(4, 'paypal', 'Pending', '2015-03-24 06:36:07'),
(5, 'cash_on_delivery', 'Pending', '2015-03-25 05:51:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `product_id` int(5) NOT NULL AUTO_INCREMENT,
  `category_id` int(3) NOT NULL,
  `manufacturer_id` int(3) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_description` text NOT NULL,
  `product_image` varchar(256) NOT NULL,
  `product_price` varchar(10) NOT NULL,
  `product_quantity` int(3) NOT NULL,
  `featured_product` tinyint(1) NOT NULL,
  `created_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `category_id`, `manufacturer_id`, `product_name`, `product_description`, `product_image`, `product_price`, `product_quantity`, `featured_product`, `created_date_time`, `publication_status`) VALUES
(10, 6, 5, 'S S C English for Today Book', '              <div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        <div class="gen-div-2">\r\n                                            <span class="float-left">Get it in 2-5 working days</span>\r\n                                        </div>', './image/product_image/bookcovers_689041.GIF', '120', 1, 1, '2015-03-23 14:33:29', 1),
(11, 6, 6, 'Secendary Physics', '              <div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        \r\n                                            <span class="float-left">Get it in 2-5 working day</span>', './image/product_image/bookcovers_68905.GIF', '100', 4, 1, '2015-03-23 03:26:03', 1),
(12, 6, 7, 'Secendary Accounting', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>', './image/product_image/bookcovers_68919.GIF', '150', 2, 1, '2015-03-23 03:27:48', 1),
(13, 6, 8, 'Secendary Science', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        <div class="gen-div-2">\r\n                                            <span class="float-left">Get it in 2-5 working days</span>\r\n                                        </div>', './image/product_image/bookcovers_68921.gif', '200', 14, 1, '2015-03-23 03:28:57', 1),
(14, 7, 5, 'একাত্তরের দিনগুলি ', '\r\n              <div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/imgrok0526_23821.GIF', '180', 5, 1, '2015-03-23 03:31:06', 1),
(15, 7, 6, ' বাংলাদেশের গেরিলা যুদ্ধ ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/imgrok0526_238211.GIF', '250', 15, 1, '2015-03-23 03:32:20', 1),
(16, 7, 7, ' মুক্তিযুদ্ধে বাংলাদেশ ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/imgrok_2099.GIF', '150', 15, 1, '2015-03-23 03:33:37', 1),
(17, 7, 7, ' স্বাধীনতা’৭১ (Book) ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/rokimg_2111_3878.gif', '150', 12, 1, '2015-03-23 03:34:51', 1),
(19, 8, 5, 'প্রাথমিক গণিতের ব্যাকরণ ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/rokimg_20150302_97426.gif', '100', 12, 1, '2015-03-23 03:37:58', 1),
(20, 8, 6, ' মহাসাগরের মহাবিস্ময়-প্রথম খণ্ড', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>', './image/product_image/rokimg_20150224_96959.gif', '150', 12, 1, '2015-03-23 03:39:11', 1),
(21, 8, 7, ' গল্পে গল্পে গণিত', '\r\n              <div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        <div class="gen-div-2">\r\n                                            <span class="float-left">Get it in 2-5 working days</span>\r\n                                        </div>', './image/product_image/rokimg_20150224_96893.gif', '100', 5, 1, '2015-03-23 03:40:33', 1),
(22, 8, 8, 'ফান্ডামেন্টাল সাইন্স অব হিউম্যান বডি ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/rokimg_20150215_95495.gif', '180', 5, 1, '2015-03-23 03:41:58', 1),
(23, 9, 8, ' মাইক্রোওয়েভ ওভেনে রান্না', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/imgrok0526_893.GIF', '150', 5, 1, '2015-03-23 03:43:34', 1),
(24, 9, 7, 'নকশা ১০০ রান্না : মাংস ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/imgrok0610_18186.gif', '100', 5, 1, '2015-03-23 03:44:57', 1),
(25, 9, 6, ' রান্নার জাদুকর ফখরুদ্দিন বাবুর্চি : ৮০ টি দুর্লভ রেসিপি ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/rokimg_20140709_34829.gif', '150', 100, 1, '2015-03-23 03:45:49', 1),
(26, 9, 5, ' টমি মিয়া’স কিচেন (Book) ', '<div class="gen-div">\r\n                                            <span class="float-left fnt-1">Only 50 Taka Delivery Cost on any amount of purchases</span>\r\n                                            <div class="gen-div-2">(Pay Cash on Delivery all around Bangladesh)</div>\r\n                                        </div>\r\n                                        ', './image/product_image/imgrok0610_7646.GIF', '100', 5, 1, '2015-03-23 03:46:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE IF NOT EXISTS `tbl_shipping` (
  `shipping_id` int(7) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `contact_number` varchar(14) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(15) NOT NULL,
  `country` varchar(25) NOT NULL,
  `zip_code` varchar(5) NOT NULL,
  PRIMARY KEY (`shipping_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `name`, `email_address`, `contact_number`, `address`, `city`, `country`, `zip_code`) VALUES
(1, '0', '0', '0', '0', '0', '0', '0'),
(2, 'nafiul islam', 'nafiul@gmail.com', '0123546789', 'dhaka', 'dhaka', 'BD', '1205'),
(3, 'Kowshik Ahmed', 'topu@abc.com', '01914872766', 'Pabna,Ishurdi', 'Ishurdi', 'BD', '6622'),
(4, 'Saahil Alam Talha', 'saahil.alam@gmail.com', '01711231142', 'House#10,North Road Dhanmondi, Dhaka', 'Dhaka', 'BD', '1205');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
