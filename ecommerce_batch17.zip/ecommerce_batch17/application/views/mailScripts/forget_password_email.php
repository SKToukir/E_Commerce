<h3>Hello, <?php echo $last_name;?></h3>
<span>Your New Password</span>
<br/>
<span>Password : <?php echo $password;?></span>
<br/>

<h3>Thank you To Join our community !</h3>
