

<h3>Hello, <?php echo $last_name;?></h3>
<br/>
<span>
    Your User Activation is Done!!!!!
</span>
<br/>
<span>
    You can Login. for more information feel free to contact 
</span>
<br/>

<h3>Thank you To Join our community !</h3>

