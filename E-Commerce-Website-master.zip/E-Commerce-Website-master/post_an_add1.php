<?php 
require('connect.php');
echo "fds";
session_start();
    //LOGIN PHP SCRIPT
      if (isset($_POST['product']) && isset($_POST['desc1']) && isset($_POST['desc2']) && isset($_POST['desc3'])  && isset($_POST['desc4'])  && isset($_POST['uploadedfile'])  && isset($_POST['brand'])  && isset($_POST['model'])  && isset($_POST['dimen'])  && isset($_POST['price'])){
        $product = $_POST['product'];
        $desc1 = $_POST['desc1'];
        $desc2 = $_POST['desc2'];
        $desc3 = $_POST['desc3'];
        $desc4 = $_POST['desc4'];
        $image = $_POST['uploadedfile'];
        $brand = $_POST['brand'];
        $model = $_POST['model'];
        $dimension = $_POST['dimen'];
        $price = $_POST['price'];
        // $checkbox = $_POST['checkbox'];
        $q="SELECT * FROM `PRODUCT` ORDER BY `PRODUCT_ID` DESC LIMIT 1";
        $ram = mysqli_query($connection,$q) or die(mysqli_error($connection));
        $i = mysqli_fetch_array($ram);
        //echo $i['PRODUCT_ID'];
        $t=$i['PRODUCT_ID']+1;
        //echo $product;
        //$query = "SELECT PASSWORD FROM `SignupCUSTOMER` (EMAIL_ID) WHERE EMAIL_ID=$email";
        $query= "INSERT INTO  `PRODUCT` VALUES ('$t','$product','0','$desc1','$desc2','$desc3','$desc4','$image','$brand','$model','$dimension','$price','2','0')";
        $result = mysqli_query($connection,$query) or die(mysqli_error($connection));

  //       $target_path = "img/olx/";
		// $target_path = $target_path . basename($_FILES['uploadedfile']['name']); 

		// if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
		//      echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
		//     " has been uploaded";
		// } else{
		//      echo "There was an error uploading the file, please try again!";
		// }
        header('Location:post_an_add2.php?id='.$t);
}

?>

<!doctype html>
<html>
<head>
	<title>SMARTCART</title>
<!--<link rel="stylesheet" type="text/css" href="slick/slick.css">-->
<link rel="stylesheet" type="text/css" href="./css/bootstrap_sub.css"/> 
<link rel="stylesheet" type="text/css" href="./css/slick.css"/>
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="./css/style2.css"/>
<link rel="stylesheet" type="text/css" href="./css/style3.css"/>
<link rel="stylesheet" type="text/css" href="./css/style4.css"/>

	
</head>
<body>
<div class="headermenu">
	<em><div class="headermenu-box"><a class="headermenu-name headermenu-color"  style="float:left;" >SmartCart</a></div></em>
	<div class="headermenu-searchbox"><input type="text" class="headermenu-search" placeholder="search for a product, category or brand"/>
	<input type="button" class="headermenu-button headermenu-button-color" value="SEARCH"/></div>
		<a href="index.php" style="text-decoration:none;" ><div class="quicksell" tabindex="1" target=" _self"><div class="quicksell-text2">
		Home</div>
	</div></a>
	<div class="mycart">
	<div class="mycart-quantity" >0</div>
	<a href="my_cart_page.html" style="text-decoration:none;"><div class="mycart2">My Cart </div>
	</div></a>
<?php
        if($_SESSION['login_user']!=NULL)
            $r='<a href="logout.php" class="login2" style="font-size:20px">'.$_SESSION['login_user'].' | LogOut</a>';
        else
            $r="LogIn | SignUp";
    ?>
    <a href="login.php"><div class="login_signup" style="text-decoration:none;">
        <div class="login2"><?php echo $r; ?></div>
    </div></a></div>
</div>
</div>
<div class="bigbox">
	<div class="two-box">

		<div class="two-one-box">
			<div class="two-one-box-text" style="color:#333;">LOGIN</div>
		</div>

		<div class="two-one-box">
			<div class="two-one-box-text">POST A FREE QUALIFIED ADD</div>
		</div>
	
		<div class="two-one-box">
			<div class="two-one-box-text2">SELLER INFORMATION</div>
		</div>
	</div>

<form action="" method="POST">
	<div class="whitebox">
		<div class="add-title">Post a Free Qualified Add</div>

		<div class="title-box-total">
		<div class="name-box">
			<div class="detail-product" >Product name :</div> 
		</div>
	    <input type="text" name="product" class="button-box" placeholder="name with a category enclosed "/>
	    </div>


	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product"> Description 1:</div> 
		</div>
	    <input type="text" name="desc1" class="button-box" placeholder="main description about the shipping and address"/>
	    </div>
    	
    	<div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">2 :</div> 
		</div>
	    <input type="text" name="desc2" class="button-box" placeholder="description about the product "/>
	    </div>

	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">3:</div> 
		</div>
	    <input type="text" name="desc3" class="button-box" placeholder="description about the product "/>
	    </div>

	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">4:</div> 
		</div>
	    <input type="text" name="desc4" class="button-box" placeholder="description about the product "/>
	    </div>

	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">Image:</div> 
		</div>
	    <input name="uploadedfile" type="file" class="button-box2" />
	    </div>

	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">Product Details:</div> 
		</div>
	    </div>

<table class="table-details">
<tr>
<td class="fixed-coloumn">Brand/Publisher:</td>
<td class="variable-coloumn"><input type="text" value="brand name should go here" name="brand"></input></td>
</tr>
<tr>
<td class="fixed-coloumn">Model/Edition:</td>
<td class="variable-coloumn"><input type="text" value="Model name" name="model"></input></td>
</tr>
<tr>
<td class="fixed-coloumn">Product Dimensions/Author:</td>
<td class="variable-coloumn"><input type="text" value="PRODUCT_DIMENSIONS/PRODUCT_AUTHOR" name="dimen"></input></td>
</tr>
<tr>
<td class="fixed-coloumn">Price:</td>
<td class="variable-coloumn variable-coloumn2" ><input type="text" value="price" name="price"></input></td>
</tr>
</table>
</div>
<input type="checkbox" class="checkbox" />
<div class="final-text">The above mentioned details are correct</div>
<button type="submit" class="final-button">Proceed</button> 
</form>
</div>


</body>
</html>