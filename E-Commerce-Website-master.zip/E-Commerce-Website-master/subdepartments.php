<?php
include 'dept_id_name.php';
include 'pagination.php';
include('session.php');

?>
<!doctype html>
<html>
<head>
	<title>SMARTKART</title>
<!--<link rel="stylesheet" type="text/css" href="slick/slick.css">-->

<link rel="stylesheet" type="text/css" href="./css/bootstrap_sub.css"/> 
<link rel="stylesheet" type="text/css" href="./css/slick.css"/>
<link rel="stylesheet" type="text/css" href="./css/style4.css"/>
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="./css/style2.css"/>
<link rel="stylesheet" type="text/css" href="./css/style3.css"/>
<link rel="stylesheet" type="text/css" href="./css/style5.css"/>
	
</head>
<body>
<div class="headermenu">
	<em><div class="headermenu-box"><a class="headermenu-name headermenu-color"  style="float:left;" >SmartCart</a></div></em>
	<div class="headermenu-searchbox"><input type="text" class="headermenu-search" placeholder="search for a product, category or brand"/>
	<input type="button" class="headermenu-button headermenu-button-color" value="SEARCH"/></div>
		<a href="index.php" style="text-decoration:none;" ><div class="quicksell" tabindex="1" target=" _self"><div class="quicksell-text2">
		Home</div>
	</div></a>
	<div class="mycart">
	<div class="mycart-quantity" >0</div>
	<a href="my_cart_page.php" style="text-decoration:none;"><div class="mycart2">My Cart </div>
	</div></a>
 <?php
        if($login_session!=NULL)
            $r='<a href="logout.php" class="login2" style="font-size:20px">'.$login_session.' | LogOut</a>';
        else
            $r="LogIn | SignUp";
    ?>
    <a href="login.php"><div class="login_signup" style="text-decoration:none;">
        <div class="login2"><?php echo $r; ?></div>
    </div></a>
</div>
</div>
<div class="nav-bar2">
</div>
<div class="row">
                    <h2><div class="new_exclusive">
Now You are in Search of 

    <?php 
        $dept_id= $_GET['dept']; 
        dept_name($dept_id);
    ?>
</div></h2>
<?php
require('connect.php');
$dept_id=$_GET['dept'];
$rec_limit=6;
$sqlquery = "SELECT count(*) FROM PRODUCT WHERE PRODUCT_SUB_DEPARTMENT=$dept_id;";
$retval = mysqli_query($connection,$sqlquery);

$row = mysqli_fetch_array($retval);

$rec_count = $row[0];
if( isset($_GET['page']))
{
   $page = $_GET['page'];
   error_log($page);
   $offset = ($rec_limit * $page)+1;
}
else
{
   $page = 0;
   $offset = 0;
}
$left_rec = $rec_count - (($page+1) * $rec_limit);
$dept_id--;
$sql = "SELECT PRODUCT_ID,PRODUCT_PRICE,PRODUCT_NAME,PRODUCT_DESCRIPTION_ONE,PRODUCT_REVIEWS,PRODUCT_IMAGE ".
       "FROM PRODUCT WHERE PRODUCT_SUB_DEPARTMENT=$dept_id ".
       "LIMIT $offset, $rec_limit";
$retvalue = mysqli_query($connection,$sql);
while($row = mysqli_fetch_array($retvalue,MYSQLI_NUM))
{
    echo '
                                        <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <a href="product_description_smartcart.php?pid='.$row[0].'"><img src="'.$row[5].'" alt="" style="width:320px;height:150px;"/></a>
                            <div class="caption">
                                <h4 class="pull-right">'.$row[1].'</h4>
                                <h4><a href="product_description_smartcart.php" style="font-size:20px">'.$row[2].'</a>
                                </h4>
                                <p style="font-size:17px" >'.$row[3].'</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right" style="font-size:15px;">'.$row[4].' reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                </p>
                            </div>
                        </div>
                    </div>';
} 
if($page!=0)
{
    $new_page1=$page-1;
  echo "<a href='subdepartments.php?dept=$dept_id&page=$new_page1'>Previous Page</a>";   
}

if($left_rec>0)
{
    $new_page=$page+1;
echo "<a href='subdepartments.php?dept=$dept_id&page=$new_page'>Next Page</a>";    
}          
?>                
</body>
</html>

				

				