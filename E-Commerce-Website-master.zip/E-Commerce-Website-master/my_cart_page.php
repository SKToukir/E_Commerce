<?php 
require('connect.php');
session_start();

if($_GET['id']!=NUll){
	 	$r=$_GET['id'];
	 	$_SESSION['id']=$r;
}
else
	$r=$_SESSION['id'];
    $query="SELECT * FROM `PRODUCT` WHERE PRODUCT_ID='$r'";
    $result = mysqli_query($connection,$query) or die(mysqli_error());
    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);



?>

<!doctype html>
<html>
<head>
	<title>SMARTCART</title>
<!--<link rel="stylesheet" type="text/css" href="slick/slick.css">-->
<link rel="stylesheet" type="text/css" href="./css/bootstrap_sub.css"/> 
<link rel="stylesheet" type="text/css" href="./css/slick.css"/>
<link rel="stylesheet" type="text/css" href="./css/style4.css"/>
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="./css/style2.css"/>
<link rel="stylesheet" type="text/css" href="./css/style3.css"/>
<link rel="stylesheet" type="text/css" href="./css/style5.css"/>
	
</head>
<body>
<div class="headermenu">
	<em><div class="headermenu-box"><a class="headermenu-name headermenu-color"  style="float:left;" >SmartCart</a></div></em>
	<div class="headermenu-searchbox"><input type="text" class="headermenu-search" placeholder="search for a product, category or brand"/>
	<input type="button" class="headermenu-button headermenu-button-color" value="SEARCH"/></div>
		<a href="index.php" style="text-decoration:none;" ><div class="quicksell" tabindex="1" target=" _self"><div class="quicksell-text2">
		Home</div>
	</div></a>
	<div class="mycart">
	<div class="mycart-quantity" >0</div>
	<a href="my_cart_page.php" style="text-decoration:none;"><div class="mycart2">My Cart </div>
	</div></a>
 <?php
        if($_SESSION['login_user']!=NULL)
            $r='<a href="logout.php" class="login2" style="font-size:20px">'.$_SESSION['login_user'].' | LogOut</a>';
        else
            $r="LogIn | SignUp";
    ?>
    <a href="login.php"><div class="login_signup" style="text-decoration:none;">
        <div class="login2"><?php echo $r; ?></div>
    </div></a></div>
</div>
</div>
<div class="nav-bar2">
</div>
<div class="nav-bar2">
<div class="display_image"></div>	
<div class="display_message">An Item added to your Cart.</div>	
</div>
<div class="cart_box">
	<div class="small-box">
	<div class="order-subtotal">Order Subtotal :</div>
	<div class="amount">Rs.</div>
	<div class="amount2"> <?php echo $row['PRODUCT_PRICE']; ?></div>
	<div class="amount3">1</div>
	<div class="amount4">item in your cart</div>
    </div>

    <div class="small-box2">
    	<a href="cod.php" ><button class="final-button2">Proceed to Payment </button></a>
    </div>
</div>


<div class="small-box3">
	<?php echo '<img class="small-box4" src="'.$row['PRODUCT_IMAGE'].'">'; ?> 
	<div class="small-box5">
		<span class="img-title2"> <?php echo $row['PRODUCT_NAME']; ?></span>
<span class="sponsorer-name-color">Rs.<?php echo $row['PRODUCT_PRICE']; ?></span>

<!--     	<input type="button" class="final-button3" value="Remove from Cart"> 	 -->
   
	</div>
 </div>


</body>
</html>
