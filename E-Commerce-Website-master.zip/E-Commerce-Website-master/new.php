<?php
$to = "siddu244@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: wsiddu244@gmail.co" . "\r\n" .
"CC: shivasagarboraiah@gmail.com";


if(mail($to,$subject,$txt,$headers))
	echo "sent";
else
	echo "not sent";
?>