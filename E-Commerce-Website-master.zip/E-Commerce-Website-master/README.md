smartcart
=========
Clone the webiste to /var/www/ folder and can be accessed using http://localhost/smartcart in your browser.

Website built using : 
  HTML, CSS, PHP ,Jquery and BOOTSTRAP
  
