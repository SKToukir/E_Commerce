<?php 
require('connect.php');
require('session.php');

session_start();
	$nam=$_SESSION['login_user'];
	$query= "SELECT * FROM `SignupCUSTOMER` WHERE `CUSTOMER_FIRST_NAME`='$nam'";
	$result = mysqli_query($connection,$query) or die(mysqli_error());
	$row=mysqli_fetch_array($result);
	$t=$row['EMAIL_ID'];
	$m=$_GET['id'];
    //LOGIN PHP SCRIPT
      if (isset($_POST['num']) && isset($_POST['addr1']) && isset($_POST['age']) && isset($_POST['addr2'])){
        $num = $_POST['num'];
        $addr1 = $_POST['addr1'];
		$addr2 = $_POST['addr2'];
		$age = $_POST['age'];        
		$q="INSERT INTO `seller` VALUES('$age','$num','$addr1','$addr2','$m')";
		$r = mysqli_query($connection,$q) or die(mysqli_error($connection));
		// $msg = 'Your add has been posted successfully.		contact no:'.$num.' ';
		// mail($t,"SMARTCART ADD",$msg);
		header('Location:index.php');
}

?>

<!doctype html>
<html>
<head>
	<title>SMARTCART</title>
<!--<link rel="stylesheet" type="text/css" href="slick/slick.css">-->
<link rel="stylesheet" type="text/css" href="./css/bootstrap_sub.css"/> 
<link rel="stylesheet" type="text/css" href="./css/slick.css"/>
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="./css/style2.css"/>
<link rel="stylesheet" type="text/css" href="./css/style3.css"/>
<link rel="stylesheet" type="text/css" href="./css/style4.css"/>

	
</head>
<body>
<div class="headermenu">
	<em><div class="headermenu-box"><a class="headermenu-name headermenu-color"  style="float:left;" >SmartCart</a></div></em>
	<div class="headermenu-searchbox"><input type="text" class="headermenu-search" placeholder="search for a product, category or brand"/>
	<input type="button" class="headermenu-button headermenu-button-color" value="SEARCH"/></div>
		<a href="index.php" style="text-decoration:none;" ><div class="quicksell" tabindex="1" target=" _self"><div class="quicksell-text2">
		Home</div>
	</div></a>
	<div class="mycart">
	<div class="mycart-quantity" >0</div>
	<a href="my_cart_page.html" style="text-decoration:none;"><div class="mycart2">My Cart </div>
	</div></a>
<?php
        if($_SESSION['login_user']!=NULL)
            $r='<a href="logout.php" class="login2" style="font-size:20px">'.$_SESSION['login_user'].' | LogOut</a>';
        else
            $r="LogIn | SignUp";
    ?>
    <a href="login.php"><div class="login_signup" style="text-decoration:none;">
        <div class="login2"><?php echo $r; ?></div>
    </div></a></div>
</div>
</div>
<div class="bigbox">
	<div class="two-box">
		<div class="two-one-box">
			<div class="two-one-box-text" style="color:#444;">LOGIN</div>
		</div>

		<div class="two-one-box">
			<div class="two-one-box-text" style="color:#444;">POST A FREE QUALIFIED ADD</div>
		</div>
	
		<div class="two-one-box">
			<div class="two-one-box-text">SELLER INFORMATION</div>
		</div>
	</div>


<div class="whitebox">
		<div class="add-title">Seller Information</div>
    	
    	<div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">Email Address:</div> 
		</div>
		<div class="button-box">
		<?php echo $row['EMAIL_ID']; ?>
	</div>
	    </div>
<form action="" method="POST">
	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">Age:</div> 
		</div>
	    <input type="text" class="button-box" name="age" placeholder="AGE"/>
	    </div>


		<div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">Phone number:</div> 
		</div>
	    <input type="text" class="button-box" name="num" placeholder="0XXXXXXXXX"/>
	    </div> 
	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">Permanent address 1:</div> 
		</div>
	    <input type="text" class="button-box" name="addr1" placeholder="address to recive the product"/>
	    </div>

	    <div class="title-box-total">
		<div class="name-box">
			<div class="detail-product">2:</div> 
		</div>
	    <input type="text" class="button-box" name="addr2" placeholder="address to recive the product"/>
	    </div>
</div>

<input type="checkbox" class="checkbox" />
<div class="final-text">The above mentioned details are correct</div>
<button type="submit" class="final-button" >POST</button> 

</form>

</div>


</body>
</html>