<?php
$connection = mysqli_connect('localhost', 'root', 'tkmysql');
if (!$connection){
    die("Database Connection Failed" . mysqli_error());
}
$select_db = mysqli_select_db($connection,'ec');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error());
}
