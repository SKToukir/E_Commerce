<?php
function paging($dept_id){
$rec_limit=6;
$sql = "SELECT count(*) FROM PRODUCT WHERE PRODUCT_SUB_DEPARTMENT=$dept_id;";
$retval = mysqli_query($conn,$sql);
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
$row = mysqli_fetch_array($retval);
$rec_count = $row[0];

if( isset($_GET['page']))
{
   $page = $_GET['page'];
   $offset = $rec_limit * $page ;
}
else
{
   $page = 0;
   $offset = 0;
}
$left_rec = $rec_count - ($page * $rec_limit);
$sql = "SELECT PRODUCT_ID,PRODUCT_PRICE,PRODUCT_NAME,PRODUCT_DESCRIPTION_ONE,PRODUCT_REVIEWS ".
       "FROM PRODUCT WHERE PRODUCT_SUB_DEPARTMENT=$dept_id ".
       "LIMIT $offset, $rec_limit";

$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysqli_fetch_array($retval,MYSQLI_NUM))
{
    echo '
                                        <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <a href="product_description_smartcart.html?'.$row[0].'"><img src="./img/'.$row[0].'.jpg" alt="" style="width:320px;height:150px;"/></a>
                            <div class="caption">
                                <h4 class="pull-right">'.$row[1].'</h4>
                                <h4><a href="product_description_smartcart.html" style="font-size:20px">'.$row[2].'</a>
                                </h4>
                                <p style="font-size:17px" >'.$row[3].'</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right" style="font-size:15px;">'.$row[4].' reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                </p>
                            </div>
                        </div>
                    </div>';
} 

if( $page > 0 )
{
   $last = $page - 2;
   echo "<a href=\"$_PHP_SELF?page=$last\">Last 6 Items</a> |";
   echo "<a href=\"$_PHP_SELF?page=$page\">Next 6 Items</a>";
}
else if( $page == 0 )
{
   echo "<a href=\"$_PHP_SELF?page=$page\">Next 6 Items</a>";
}
else if( $left_rec < $rec_limit )
{
   $last = $page - 2;
   echo "<a href=\"$_PHP_SELF?page=$last\">Last 6 Items</a>";
}
}
?>