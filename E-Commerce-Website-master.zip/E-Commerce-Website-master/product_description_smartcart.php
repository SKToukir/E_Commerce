<?php
    include 'connect.php';
    include('session.php');
    $r=$_GET['pid'];
    $query="SELECT * FROM `PRODUCT` WHERE PRODUCT_ID='$r'";
    $result = mysqli_query($connection,$query) or die(mysqli_error());
    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
    $n="my_cart_page.php?id=".$r;
    //echo $r;

?>

<!doctype html>
<html>
<head>
	<title>SMARTCART</title>
<!--<link rel="stylesheet" type="text/css" href="slick/slick.css">-->
<link rel="stylesheet" type="text/css" href="./css/bootstrap_sub.css"/> 
<link rel="stylesheet" type="text/css" href="./css/slick.css"/>
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="./css/style2.css"/>
	
</head>
<body>
<div class="headermenu">
	<em><div class="headermenu-box"><a class="headermenu-name"  style="float:left;" >SmartCart</a></div></em>
	<div class="headermenu-searchbox"><input type="text" class="headermenu-search" placeholder="search for a product, category or brand"/>
	<input type="button" class="headermenu-button " value="SEARCH"/></div>
		<a href="index.php" style="text-decoration:none;" ><div class="quicksell" tabindex="1" target=" _self"><div class="quicksell-text2">
		Home</div>
	</div></a>
	<div class="mycart">
	<div class="mycart-quantity" >0</div>
	<a href="my_cart_page.html" style="text-decoration:none;"><div class="mycart2">My Cart </div>
	</div></a>
 <?php
        if($login_session!=NULL)
            $r='<a href="logout.php" class="login2" style="font-size:20px">'.$login_session.' | LogOut</a>';
        else
            $r="LogIn | SignUp";
    ?>
    <a href="login.php"><div class="login_signup" style="text-decoration:none;">
        <div class="login2"><?php echo $r; ?></div>
    </div></a>
</div></div>


<div class="nav-bar2">
</div>
<div class="img-description-box">
<?php echo '<img class="big-image-box" src="'.$row['PRODUCT_IMAGE'].'">'; ?> 
<div class="img-desc-box">
<div class="img-title-box"><span class="img-title"><?php echo $row['PRODUCT_NAME']; ?></span></div>
<div class="by">by   </div>
<span class="sponsorer-name"><?php echo $row['PRODUCT_BRAND/PRODUCT_PUBLISHER']; ?></span>
<div class="by">price</div>
<span class="sponsorer-name-color">Rs.<?php echo $row['PRODUCT_PRICE']; ?></span>
<div class="by">review</div>
                                <p>
                                    <span class="glyphicon glyphicon-star review-product"></span>
                                    <span class="glyphicon glyphicon-star review-product2"></span>
                                    <span class="glyphicon glyphicon-star review-product2"></span>
                                    <span class="glyphicon glyphicon-star review-product2"></span>
                                    <span class="glyphicon glyphicon-star review-product2"></span>
                                </p>
<div class="navigator"></div>
<ul class="list">
<li class="list-main"><?php echo $row['PRODUCT_DESCRIPTION_ONE']; ?></li>
<li class="list-sub"> <?php echo $row['PRODUCT_DESCRIPTION_2']; ?></li>
<li class="list-sub"> <?php echo $row['PRODUCT_DESCRIPTION_3']; ?></li>
<li class="list-sub"> <?php echo $row['PRODUCT_DESCRIPTION_4']; ?></li>
<ul>
<!--<span class="description-product">two-three-line Description about the product</span>-->
<div class="navigator"></div>
<div class="img-title-box"><div class="img-technical-title">Product Details : </div></div>
<table class="table-details">
<tr>
<td class="fixed-coloumn">Brand:</td>
<td class="variable-coloumn"><?php echo $row['PRODUCT_BRAND/PRODUCT_PUBLISHER']; ?></td>
</tr>
<tr>
<td class="fixed-coloumn">Model:</td>
<td class="variable-coloumn"><?php echo $row['PRODUCT_MODEL_NO/PRODUCT_EDITION']; ?></td>
</tr>
<tr>
<td class="fixed-coloumn">Item Weight:</td>
<td class="variable-coloumn"><?php echo $row['PRODUCT_DIMENSIONS/PRODUCT_AUTHOR']; ?></td>
</tr>
<tr>
<td class="fixed-coloumn">Product Dimensions:</td>
<td class="variable-coloumn"><?php echo $row['PRODUCT_DIMENSIONS/PRODUCT_AUTHOR']; ?></td>
</tr>
<tr>
<td class="fixed-coloumn">Price:</td>
<td class="variable-coloumn variable-coloumn2" >Rs. <?php echo $row['PRODUCT_PRICE']; ?></td>
</tr>
</table>
<input type="button" value="Add a Review" name="cart" class="add-a-review"/>
<div class="quantity-name">Qty</div>
<select name="Qty: " class="quantity">
<option value="one">1</option>
<option value="two">3</option>
<option value="four">4</option>
<option value="five">5</option>
<option value="six">6</option>
<option value="seven">7</option>
<option value="eight">8</option>
<option value="nine">9</option>
<option value="ten">10</option>
</select>
<?php
//echo "Gfdgf";
$rew=$_GET['pid'];
$qu="SELECT * FROM `seller` WHERE `id`='$rew'";
    $re = mysqli_query($connection,$qu) or die(mysqli_error());
    $rowss=mysqli_fetch_array($re,MYSQLI_ASSOC);
    //echo "Gdf";
    //echo $rowss['phone'];
if($row['new']==0){
    echo '<input type="button" value="'.$rowss['phone'].'" name="cart" class="cart-submit"/>';
} 
else
    echo '<a href='.$n.'><input type="button" value="Add to Cart" name="cart" class="cart-submit"/></a>';

?>
</div>
</div>





                <div class="row">
                    <div class="new_exclusive2" >
Similar Products that You are Searching for  
</div>

<?php
    $sub=$row['PRODUCT_SUB_DEPARTMENT'];
    $q="SELECT * FROM `PRODUCT` WHERE PRODUCT_SUB_DEPARTMENT='$sub'";
    $k = mysqli_query($connection,$q) or die(mysqli_error());
    while($ro=mysqli_fetch_array($k,MYSQLI_ASSOC)){

                    echo '<div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <a href="product_description_smartcart.php?pid='.$ro['PRODUCT_ID'].'"><img src="'.$ro['PRODUCT_IMAGE'].'" alt="" style="width:320px;height:150px;"/></a>
                            <div class="caption">
                                <h4 class="pull-right">Rs. 100</h4>
                                <h4><a href="product_description_smartcart.php?pid='.$ro['PRODUCT_ID'].'" style="font-size:20px">'.$ro['PRODUCT_NAME'].'</a>
                                </h4>
                                <p style="font-size:17px" >'.$ro['PRODUCT_DESCRIPTION_ONE'].'</p>
                            </div>  
                            <div class="ratings">
                                <p class="pull-right" style="font-size:15px;">'.$ro['PRODUCT_REVIEWS'].'</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                </p>
                            </div>
                        </div>
                    </div>';
                }

?>
</body> 
</html>
