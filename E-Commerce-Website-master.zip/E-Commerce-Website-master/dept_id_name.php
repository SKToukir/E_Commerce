<?php
function dept_name($dept_id){
        switch($dept_id){
            case 1:
                echo "Books";
                break;
            case 2:
                echo "Text Books";
                break;
            case 3:
                echo "Magazines";
                break;
            case 4:
                echo "Movies";
                break;
            case 5:
                echo "Music CDs";
                break;
            case 6:
                echo "Video Games";
                break;
            case 7:
                echo "TV and Video";
                break;
            case 8:
                echo "Home Theatre and Audio";
                break;
            case 9:
                echo "Camera, Photo and Video";
                break;
            case 10:
                echo "Car Electronics";
                break;
            case 11:
                echo "Musical Instruments";
                break;
            case 12:
                echo "Kitchen and Dining";
                break;
            case 13:
                echo "Furniture and Decor";
                break; 
            case 14:
                echo "Bedding and Bath";
                break;
            case 15:
                echo "Fine Art";
                break;
            case 16:
                echo "Pet Supplies";
                break;
            case 17:
                echo "Men";
                break;
            case 18:
                echo "Women";
                break;
            case 19:
                echo "Children";
                break;
            case 20:
                echo "Exercise and Fitness";
                break;
            case 21:
                echo "Hunting and Fishing";
                break;
            case 22:
                echo "Athletic Coaching";
                break;
            case 23:
                echo "Boating and Water Sports";
                break;
            case 24:
                echo "Team Sports";
                break;                                                                                                            
        }
    }

?>